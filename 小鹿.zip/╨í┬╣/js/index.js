// made by jia jia zi fans--suan fa wang(防伪标志)

$(document).ready(function(){


    //Ajax添加上面图片的功能
    function AddImg_top(){
        let a=$(".imgxl");
        $.ajax({
            data:"json",
            type: "get",
            url:"json/index.json",
            async: false,
            success: function(msg) {
                for(let i=0;i<msg.length;i++){
                    let newimg=a.clone();
                    newimg.prop("src",msg[i].src);
                    if(i!=0){
                        newimg.appendTo(".banner-img-container");
                    }
                    
                }
            }  
        })
    }
   

    //Ajax添加下面图片的功能  以及添加打开阴影后图片的功能
    let length;
    function AddImg_main(){
        let b=$(".xlpho_div");
        let c=$(".cover_entire_img")

        
        // b.addClass("xl0");
        console.log("let length后面一点执行")
        $.ajax({
            data:"json",
            type: "get",
            url:"json/index_pho.json",
            async: false,
            success: function(msg2) {
                length=msg2.length;
                // console.log("ajax里面的length="+length)
                // console.log("length ="+length)
                var i;
                for(i=0;i<msg2.length;i++){
                    // console.log("i="+1+"时的length="+length)
                    var newdiv=b.clone()
                    /*这里newdiv_shadow
                    是克隆给到打开图片后阴影的中间图片，
                    刚刚开始进行克隆给下面图片的时候不用管
                    */
                    var newdiv_shadow=c.clone()
                    // newdiv.addClass("xl"+msg[i].id)
                    newdiv.find(".xl_pho").prop("src",msg2[i].src)
                    newdiv_shadow.prop("src",msg2[i].src)
                    if(i!=0){
                        // console.log("if里面的执行")
                        // console.log(i+"下标"+"对应的div的高度是"+$(".xlpho_div").eq(i).height())
                        // console.log($(".xlpho_div").eq(i))
                        newdiv.appendTo($(".photos_father"))
                        newdiv_shadow.appendTo($(".cover_entire_img_div"))
                        // console.log($(".xl_pho").eq(1).height())
                    }
                
                }



            }
        })
        // console.log("ajax完了之后length="+length)
        
    }




    //Ajax添加下面视频图片-- xl_vedio的功能
    let length_img_vedio;
    function AddVedio_main(){
        let d=$(".vedio_div");
        let e=$(".cover_entire_vedio")
        
        // b.addClass("xl0");
        console.log("let length后面一点执行")
        $.ajax({
            data:"json",
            type: "get",
            url:"json/index_vedio.json",
            async: false,
            success: function(msg2) {
                length_img_vedio=msg2.length
                // length=msg2.length;
                // console.log("ajax里面的length="+length)
                // console.log("length ="+length)
                var i;
                for(i=0;i<msg2.length;i++){
                    // console.log("i="+1+"时的length="+length)
                    
                    var newdiv=d.clone()
                    /*这里newdiv_shadow
                    是克隆给到打开vedio后阴影的中间vedio，
                    刚刚开始进行克隆给下面图片的时候不用管
                    */
                    var newdiv_shadow=e.clone()
                    // newdiv.addClass("xl"+msg[i].id)
                    newdiv.find(".xl_vedio").prop("src",msg2[i].img_src)
                    newdiv_shadow.children("source").prop("src",msg2[i].vedio_src)
                    if(i!=0){
                        // console.log("if里面的执行")
                        // console.log(i+"下标"+"对应的div的高度是"+$(".xlpho_div").eq(i).height())
                        // console.log($(".xlpho_div").eq(i))
                        newdiv.appendTo($(".vedio_father"))
                        newdiv_shadow.appendTo($(".cover_entire_vedio_div"))
                        // console.log($(".xl_pho").eq(1).height())
                    }
                
                }



            }
        })
        // console.log("ajax完了之后length="+length)
        
    }


    


    //添加图片总功能
    function AddImg(){
        AddImg_top()
        AddImg_main()   //这里已经包含了阴影部分的东西添加
        AddVedio_main() //这里已经包含了阴影部分的东西添加

        // console.log("函数执行完之后的length="+length)
    }


    //调整图片位置功能--水平方向
    function changeImg_horizontal(){
        var j
        for(j=0;j<length;j++){
            // console.log(length)
            if(j%4==1){
                $(".xlpho_div").eq(j).css("left","25%")
            }
            if(j%4==2){
                $(".xlpho_div").eq(j).css("left","50%")
            }
            if(j%4==3){
                $(".xlpho_div").eq(j).css("left","75%")
            }   
        }
    }

    //调整图片位置--垂直方向
    function changeImg_vertical(){
        var height;
        var q;
        // console.log($(".xlpho_div").eq(0).height())
        // console.log($(".xlpho_div").eq(1).height())
        // console.log($(".xlpho_div").eq(2).height())
        // console.log($(".xlpho_div").eq(3).height())
        for(q=0;q<length;q++){
            height=0;
            var h=parseInt(q/4)
            var l=parseInt(q%4)
            for(var k=0;k<=h-1;k++){
                
                    // console.log("q是"+q)
                    
                    height=height+$(".xlpho_div").eq(q-4*(k+1)).height()
                    var height2=$(".xlpho_div").eq(q).height()
                    console.log(q+"下标对应的div的高度(自身)是"+height2)

                    // console.log("q对应div的top是"+height)
                
                
                // console.log(q-4*(k+1))
                // console.log(height)
            }
            $(".xlpho_div").eq(q).css("top",height)
            
        }
    }


    //自动调的算法没什么问题，不过请求有点冲突，这里加一种手动方法
    function changeImg_vertical_shoudong(){
        // console.log($(".xlpho_div").eq(0).height())
        // console.log($(".xlpho_div").eq(1).height())
        // console.log($(".xlpho_div").eq(2).height())
        // console.log($(".xlpho_div").eq(3).height())
        
        

        $(".xlpho_div").eq(4).css("top","450px")
        $(".xlpho_div").eq(5).css("top","550px")
        $(".xlpho_div").eq(6).css("top","550px")
        $(".xlpho_div").eq(7).css("top","450px")

        $(".xlpho_div").eq(8).css("top","1080px")
        $(".xlpho_div").eq(9).css("top","600px")
        $(".xlpho_div").eq(10).css("top","30px")
        $(".xlpho_div").eq(11).css("top","440px")
    }


    function changImg_vedio_horizontal(){
        var j
        for(j=0;j<length_img_vedio;j++){
            // console.log(length)
            if(j%4==1){
                $(".vedio_div").eq(j).css("left","25%")
            }
            if(j%4==2){
                $(".vedio_div").eq(j).css("left","50%")
            }
            if(j%4==3){
                $(".vedio_div").eq(j).css("left","75%")
            }   
        }
    }


    function changeImg_vedio_vertical_shoudong(){
        $(".vedio_div").eq(4).css("top","450px")
        $(".vedio_div").eq(5).css("top","550px")
        $(".vedio_div").eq(6).css("top","550px")
        $(".vedio_div").eq(7).css("top","450px")

        $(".vedio_div").eq(8).css("top","1080px")
        $(".vedio_div").eq(9).css("top","600px")
        $(".vedio_div").eq(10).css("top","30px")
        $(".vedio_div").eq(11).css("top","440px")
    }




    //调整图片总功能

    function changImg(){
        changeImg_horizontal()
        changeImg_vertical_shoudong()
        
    }

    function changImg_vedio(){
        changImg_vedio_horizontal()
        changeImg_vedio_vertical_shoudong()
    }

   
    AddImg()

    changImg()
    
    changImg_vedio()



    


    

    //调整高度

    //把每一行每一列的某一个div的索引的值存到数组里面
    //a[0][0] --一行一列
    // var arr=new Array(length)
    // for(var q=0;q<length;q++){
    //     var h=$(".xlpho_div").index()/4
    //     var l=$(".xlpho_div").index()%4
    //     arr[h][l]=$(".xlpho_div").index();
    // }

    //取一个图片为例，每一个图片距离大div有多远，设置top
    //去遍历同一列的每一行的height，把某个图片上面所有图片的
    //height全加起来，而且还要加间隔，就得到了这个图片的
    //top
    

//图片位置调整完了 ，接下来的上面图片的效果



//图片切换效果
let i=0;
$(".imgxl").eq(0).css("opacity","1");
function change_right(){

    //这里是消失算法
    $(".imgxl").eq(i).css("opacity","0")

    i = i + 1;
    if (i > 1) {
        i = 0;
    }
    
  //这里是出现算法
    $(".imgxl").eq(i).css("opacity","1") 

    
       
}

function change_left(){

    //这里是消失算法
    $(".imgxl").eq(i).css("opacity","0")

    i = i - 1;
    if (i < 0) {
        i = 1;
    }
    
  //这里是出现算法
    $(".imgxl").eq(i).css("opacity","1")

    
    
}

    //自动轮播图片功能
    var lunbo  //这里为了让后面点击时候，重置轮播的时间
     function autoplay(){ 
        lunbo=setInterval(function(){
            change_right();
        },5000) 
         
     }


    //自动轮播图片
    autoplay()



    $(".prev_right").click(function(){
          //先把动画暂停
          $(".imgxl").eq(i).stop(true, true);

          //切换图片
          change_right()  

          //重置自动轮播时间
          clearInterval(lunbo)

        //   autoplay()
          
    })

    


    $(".prev_left").click(function(){

        //先把动画暂停
        $(".imgxl").eq(i).stop(true, true);

        //切换图片
        change_left()  

        //重置自动轮播时间
        clearInterval(lunbo)

        autoplay()
        
    })

    //箭头触碰
    $(".prev_right, .prev_left").mouseover(function(){
        $(this).css("background-color","rgba(240, 50, 84)")
    })

    $(".prev_right, .prev_left").mouseleave(function(){
        $(this).css("background-color","rgba(31, 31, 31, 0.7)")
        
    })



    //上面照片中间的文字效果

    $(".text_top_text_third").mouseover(function(){
        $(this).css("background-color","rgba(252, 96, 96,1)")
    })

    $(".text_top_text_third").mouseleave(function(){
        $(this).css("background-color","rgba(0, 0, 0, 0)")
    })

    $(".text_top_text_fourth").mouseover(function(){
        $(this).css("color","rgba(245, 94, 94,1)")
    })

    $(".text_top_text_fourth").mouseleave(function(){
        $(this).css("color","white")
    })

        

    //上方导航栏触碰效果
    $("#navigation ul li").mouseover(function(){
        $(this).css("background-color","rgba(0,0,0,0.1)");
    })

    $("#navigation ul li").mouseleave(function(){
        $(this).css("background-color","rgba(0,0,0,0.8)");
    })



    //中间导航栏触碰效果

    $(".center_navigation>div a").hover(function(){
        $(this).parent("div").css("border-bottom","3px solid")
        $(this).parent("div").css("border-bottom-color","red")
       
    })
    
     $(".center_navigation>div a").mouseleave(function(){
        $(this).parent("div").css("border-bottom","1px solid")
        $(this).parent("div").css("border-bottom-color","rgba(256, 256, 256, 0.1)")
        
     })



     /*点击视频选项效果*/

     $(".shiping").click(function(){
        $(".photos_father").hide()
        $(".vedio_father").show()
     })

     $(".zhaopian").click(function(){
        $(".vedio_father").hide()
        $(".photos_father").show()
     })





     //下面的图片触碰效果

     $(".xlpho_div").mouseover(function(){
        $(this).children(".cover").show();
        $(this).find(".in").show()
        
        //扩大图片
        $(this).find(".xl_pho").addClass("xl_pho_bigger")
        
        })
    $(".xlpho_div").mouseleave(function(){
        $(this).children(".cover").hide();
        $(this).find(".in").hide()

        //图片大小返回原样
        $(this).find(".xl_pho").removeClass("xl_pho_bigger")
     })



     //图片中加号的触碰效果

     $(".in").mouseover(function(){
        $(this).css("background-color","rgba(37, 49, 65,0.8)")
     })

     $(".in").mouseleave(function(){
        $(this).css("background-color","rgba(252, 96, 96,0.8)")
        
     })


     //点下面的图片中间加号 出来 阴影


     //这里是方便定位图片定位，让每张图片都在中间
     //不会css排布，只能用傻逼jquery算法实现了
     //算法思路是取一张图片的width，用50%的整个大盒子宽度-width/2
     //这样就可以让每张不一样width的图片处在最中间了
     var shadow_p_index=0; 
     var entire_width=$('.cover_entire').width()
     var left = entire_width*0.5
     
     $(".in").click(function(){
        
        //获取点击的加号对应的图片的索引
        shadow_p_index=$(this).parents(".xlpho_div").index()

        $(".cover_entire").show()
        $(".cover_entire_img_div").show()
        $(".cover_entire_img").eq(shadow_p_index).show()
        
        
        //这里先把阴影中间的盒子的位置调一下，之前在css中设置的是left:50%

        //xxx
        var width_cover_entire_img_div=$(".cover_entire_img").eq(shadow_p_index).width()
        // console.log(width_cover_entire_img_div)

       
        // console.log(left)
        
        // left=parseInt(left)
        var now_left=left-width_cover_entire_img_div/2

        // console.log(left)
        $(".cover_entire_img_div").css("left",now_left)
             
        
        
        
                    
     })


     //点下面的图片出来的阴影，左右的剪头触碰效果

     //左边and右边
     $(".big_jiantou_left_div , .big_jiantou_right_div").mouseover(function(){
        $(this).css("background-color","rgba(252, 96, 96,1")
     })
     
     $(".big_jiantou_left_div , .big_jiantou_right_div ").mouseleave(function(){
        $(this).css("background-color","rgba(252, 96, 96,0.6")
     })




     //点击箭头后，阴影中间的盒子显示出来

     $(".big_jiantou_right_div").click(function(){
        
        $(".cover_entire_img").eq(shadow_p_index).hide()
        shadow_p_index=shadow_p_index+1;
        if(shadow_p_index>length-1){
            shadow_p_index=0
        }
        $(".cover_entire_img").eq(shadow_p_index).show()

        /*这里装图片的div的水平位置改变一下，因为div是被点进来的那个图片
          的宽度来计算的
        */
        var width_cover_entire_img_div=$(".cover_entire_img_div").width()   
        
        var now_left=left-width_cover_entire_img_div/2
        $(".cover_entire_img_div").css("left",now_left)

        
     })

     $(".big_jiantou_left_div").click(function(){
        $(".cover_entire_img").eq(shadow_p_index).hide()
        shadow_p_index--;
        if(shadow_p_index<0){
            shadow_p_index=length-1
        }
        $(".cover_entire_img").eq(shadow_p_index).show()


        //和right箭头效果一样，自研傻逼jquery算法
        var width_cover_entire_img_div=$(".cover_entire_img_div").width()   
        
        var now_left=left-width_cover_entire_img_div/2
        $(".cover_entire_img_div").css("left",now_left)
        
     })



     //退出图片放大效果的按钮---触碰

     $(".exit_cover").mouseover(function(){
        $(this).css("background-color","rgba(252, 96, 96,1)")
     })

     $(".exit_cover").mouseleave(function(){
        $(this).css("background-color","rgba(252, 96, 96,0.6)")
     })



     //退出图片放大效果的按钮---退出
     $(".exit_cover").click(function(){
        $(".cover_entire").hide()
        // $(".cover_entire").children().hide()
        $(".cover_entire_img").hide()
     })




     //首页背景音乐

     //播放--on  停止-off

     $(".on_music").click(function(){
        $(".bfq")[0].play()

        $(this).parent().hide()
        $(".off_music").show()
     })

     $(".off_music").click(function(){
        $(".bfq")[0].pause()

        $(this).hide()
        $(".on_music").parent().show()

     })


     //on 按钮触碰和离开效果
     $(".on_music").mouseover(function(){

        $(this).parent().css("background-color","rgba(10, 11, 19,0.4)")
        
     })

     $(".on_music").mouseleave(function(){

        $(this).parent().css("background-color","rgba(10, 11, 19,0.6)")
        
     })


     //off 按钮触碰和离开效果
     $(".off_music").mouseover(function(){

        $(this).css("background-color","rgba(10, 11, 19,0.4)")
        
     })

     $(".off_music").mouseleave(function(){

        $(this).css("background-color","rgba(10, 11, 19,0.6)")
        
     })



    
     


    
})






