 $(function(){
        //下面的图片触碰效果

    $(".vedio_div").mouseover(function(){
        $(this).children(".cover_vedio").show();
        $(this).find(".in_vedio").show()
        
        //扩大图片
        $(this).find(".xl_vedio").addClass("xl_vedio_bigger")
        
        })
    $(".vedio_div").mouseleave(function(){
        $(this).children(".cover_vedio").hide();
        $(this).find(".in_vedio").hide()

        //图片大小返回原样
        $(this).find(".xl_vedio").removeClass("xl_vedio_bigger")
    })



    //图片中加号的触碰效果

    $(".in_vedio").mouseover(function(){
        $(this).css("background-color","rgba(37, 49, 65,0.8)")
    })

    $(".in_vedio").mouseleave(function(){
        $(this).css("background-color","rgba(252, 96, 96,0.8)")
        
    })


    //点下面的图片中间加号 出来 阴影


    //这里是方便定位图片定位，让每张图片都在中间
    //不会css排布，只能用傻逼jquery算法实现了
    //算法思路是取一张图片的width，用50%的整个大盒子宽度-width/2
    //这样就可以让每张不一样width的图片处在最中间了
    var shadow_v_index; 
    var entire_width=$('.cover_entire2').width()
    var left = entire_width*0.5
    
    $(".in_vedio").click(function(){
        
        //获取点击的加号对应的图片的索引
        shadow_v_index=$(this).parents(".vedio_div").index()
        


        $(".cover_entire2").show()
        $(".cover_entire_vedio_div").show()
        $(".cover_entire_vedio").eq(shadow_v_index).show()
        console.log(shadow_v_index)
        
        //这里先把阴影中间的盒子的位置调一下，之前在css中设置的是left:50%

        //获取阴影中间盒子的宽度
        var width_cover_entire_vedio_div=$(".cover_entire_vedio").eq(shadow_v_index).width()
        console.log(width_cover_entire_vedio_div)

    
        // console.log(left)
        
        // left=parseInt(left)

        //获取新的left，新的left=old_left-div_width()/2
        var now_left=left-width_cover_entire_vedio_div/2

        // console.log(left)
        $(".cover_entire_vedio_div").css("left",now_left)






        // $(".cover_entire_vedio_div").eq(shadow_v_index).children(".cover_entire_vedio").play()
                     
    })





    //退出图片放大效果的按钮---退出
    $(".exit_cover").click(function(){
        $(".cover_entire2").hide()
        // $(".cover_entire").children().hide()
        $(".cover_entire_vedio_div").hide()
        $(".cover_entire_vedio").hide()
        $(".cover_entire_vedio").get(shadow_v_index).pause()
        
     })

 })
 
 
 